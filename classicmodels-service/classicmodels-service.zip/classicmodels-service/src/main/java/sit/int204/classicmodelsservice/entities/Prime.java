package sit.int204.classicmodelsservice.entities;

public class Prime {

}
